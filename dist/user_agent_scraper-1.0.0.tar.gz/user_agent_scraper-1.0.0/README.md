# user_agent_scraper

To install or update - `pip3 install --upgrade user_agen_scraper`
You can view all possible browsers [here](http://www.useragentstring.com/pages/useragentstring.php).



`import user_agent_scraper` - Imports the module, but I think you know what this does already. <br />

`user_agent_scraper.get_valid_agents()` - Get all browsers, returned in an array <br />
`user_agent_scraper.scrape_user_agents(browsers)` - Gets all user agents for the browsers passed into an array <br />
